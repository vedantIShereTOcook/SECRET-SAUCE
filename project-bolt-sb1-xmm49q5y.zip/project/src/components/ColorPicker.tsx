import React, { useState, useRef, useEffect } from 'react';

interface ColorPickerProps {
  label: string;
  color: string;
  onChange: (color: string) => void;
}

export function ColorPicker({ label, color, onChange }: ColorPickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const colors = [
    '#000000', '#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#00ffff', '#ff00ff',
    '#808080', '#c0c0c0', '#800000', '#808000', '#008000', '#800080', '#008080', '#000080',
    '#ff4500', '#da70d6', '#fa8072', '#32cd32', '#87ceeb', '#ba55d3', '#f0e68c', '#dda0dd',
    '#90ee90', '#87cefa', '#deb887', '#d8bfd8', '#ff69b4', '#cd853f', '#4682b4', '#98fb98'
  ];

  return (
    <div className="relative" ref={pickerRef}>
      <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
      <button
        type="button"
        className="w-full h-10 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 relative overflow-hidden"
        onClick={() => setIsOpen(!isOpen)}
        style={{ backgroundColor: color }}
      >
        <span className="sr-only">Choose color</span>
      </button>
      
      {isOpen && (
        <div className="absolute z-10 mt-2 p-2 bg-white rounded-lg shadow-lg border border-gray-200 w-64">
          <div className="grid grid-cols-8 gap-1">
            {colors.map((c) => (
              <button
                key={c}
                className="w-6 h-6 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                style={{ backgroundColor: c }}
                onClick={() => {
                  onChange(c);
                  setIsOpen(false);
                }}
              >
                <span className="sr-only">Choose {c}</span>
              </button>
            ))}
          </div>
          <div className="mt-2">
            <input
              type="color"
              value={color}
              onChange={(e) => onChange(e.target.value)}
              className="w-full h-8"
            />
          </div>
        </div>
      )}
    </div>
  );
}