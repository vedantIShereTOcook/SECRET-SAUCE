import React from 'react';
import { Upload, Type, Sliders, Image as ImageIcon } from 'lucide-react';
import { WatermarkSettings } from '../types';
import { fontOptions } from '../utils/fonts';
import { ColorPicker } from './ColorPicker';

interface WatermarkFormProps {
  settings: WatermarkSettings;
  onSettingsChange: (settings: Partial<WatermarkSettings>) => void;
  onImageUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function WatermarkForm({ settings, onSettingsChange, onImageUpload }: WatermarkFormProps) {
  const currentFont = fontOptions.find(f => f.family === settings.font);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Watermark Settings</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Upload Image</label>
          <div className="flex items-center justify-center w-full">
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 mb-2 text-gray-500" />
                <p className="mb-2 text-sm text-gray-500">Click to upload or drag and drop</p>
              </div>
              <input type="file" className="hidden" accept="image/*" onChange={onImageUpload} />
            </label>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Watermark Type</label>
          <div className="flex gap-4">
            <button
              className={`flex-1 py-2 px-4 rounded-md flex items-center justify-center gap-2 ${
                settings.type === 'text' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'
              }`}
              onClick={() => onSettingsChange({ type: 'text' })}
            >
              <Type className="w-4 h-4" /> Text
            </button>
            <button
              className={`flex-1 py-2 px-4 rounded-md flex items-center justify-center gap-2 ${
                settings.type === 'image' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'
              }`}
              onClick={() => onSettingsChange({ type: 'image' })}
            >
              <ImageIcon className="w-4 h-4" /> Image
            </button>
          </div>
        </div>

        {settings.type === 'text' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Watermark Text</label>
              <input
                type="text"
                value={settings.text}
                onChange={(e) => onSettingsChange({ text: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter watermark text"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Text Size (%)</label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={settings.textSize}
                  onChange={(e) => onSettingsChange({ textSize: Number(e.target.value) })}
                  className="flex-1"
                />
                <span className="text-sm text-gray-500 w-12">{settings.textSize}%</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <ColorPicker
                label="Text Color"
                color={settings.textColor}
                onChange={(color) => onSettingsChange({ textColor: color })}
              />
              <ColorPicker
                label="Outline Color"
                color={settings.strokeColor}
                onChange={(color) => onSettingsChange({ strokeColor: color })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Font Family</label>
              <select
                value={settings.font}
                onChange={(e) => onSettingsChange({ font: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {fontOptions.map((font) => (
                  <option key={font.family} value={font.family} style={{ fontFamily: font.family }}>
                    {font.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Font Weight</label>
              <select
                value={settings.fontWeight}
                onChange={(e) => onSettingsChange({ fontWeight: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {currentFont?.weights.map((weight) => (
                  <option key={weight} value={weight}>
                    {weight}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Font Style</label>
              <select
                value={settings.fontStyle}
                onChange={(e) => onSettingsChange({ fontStyle: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {currentFont?.styles.map((style) => (
                  <option key={style} value={style}>
                    {style.charAt(0).toUpperCase() + style.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Sliders className="w-4 h-4 inline mr-2" />
            Opacity
          </label>
          <input
            type="range"
            min="0"
            max="100"
            value={settings.opacity}
            onChange={(e) => onSettingsChange({ opacity: Number(e.target.value) })}
            className="w-full"
          />
          <div className="text-sm text-gray-500 text-right">{settings.opacity}%</div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Position</label>
          <div className="grid grid-cols-3 gap-2">
            {['top-left', 'top-center', 'top-right', 'middle-left', 'middle-center', 'middle-right', 'bottom-left', 'bottom-center', 'bottom-right'].map((pos) => (
              <button
                key={pos}
                className={`p-2 rounded ${
                  settings.position === pos ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'
                }`}
                onClick={() => onSettingsChange({ position: pos })}
              >
                <div className="w-6 h-6" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}