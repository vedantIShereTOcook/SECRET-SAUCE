import React, { useRef, useEffect } from 'react';
import { WatermarkSettings } from '../types';
import { drawWatermark } from '../utils/watermark';
import { DownloadButton } from './DownloadButton';

interface WatermarkPreviewProps {
  settings: WatermarkSettings;
  sourceImage: string | null;
}

export function WatermarkPreview({ settings, sourceImage }: WatermarkPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!sourceImage || !canvasRef.current) return;

    const image = new Image();
    image.src = sourceImage;
    image.onload = () => {
      if (!canvasRef.current) return;
      drawWatermark(canvasRef.current, image, settings);
    };
  }, [sourceImage, settings]);

  if (!sourceImage) {
    return (
      <div className="bg-gray-100 rounded-lg p-8 text-center">
        <p className="text-gray-500">Upload an image to preview watermark</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Preview</h2>
        <DownloadButton canvasRef={canvasRef} />
      </div>
      <canvas
        ref={canvasRef}
        className="max-w-full h-auto rounded-lg"
      />
    </div>
  );
}