import React from 'react';
import { Download } from 'lucide-react';
import { downloadImage } from '../utils/download';

interface DownloadButtonProps {
  canvasRef: React.RefObject<HTMLCanvasElement>;
}

export function DownloadButton({ canvasRef }: DownloadButtonProps) {
  const handleDownload = () => {
    if (canvasRef.current) {
      downloadImage(canvasRef.current);
    }
  };

  return (
    <button
      onClick={handleDownload}
      className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
    >
      <Download className="w-4 h-4" />
      Download Image
    </button>
  );
}