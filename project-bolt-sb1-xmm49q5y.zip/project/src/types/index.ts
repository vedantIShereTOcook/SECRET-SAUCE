export interface WatermarkSettings {
  type: 'text' | 'image';
  text: string;
  opacity: number;
  position: string;
  font: string;
  fontWeight: string;
  fontStyle: string;
  textSize: number;
  textColor: string;
  strokeColor: string;
}

export interface FontOption {
  name: string;
  family: string;
  weights: string[];
  styles: string[];
}