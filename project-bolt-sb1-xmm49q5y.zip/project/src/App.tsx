import React, { useState } from 'react';
import { WatermarkForm } from './components/WatermarkForm';
import { WatermarkPreview } from './components/WatermarkPreview';
import { WatermarkSettings } from './types';
import { Droplets } from 'lucide-react';
import { fontOptions } from './utils/fonts';

function App() {
  const [settings, setSettings] = useState<WatermarkSettings>({
    type: 'text',
    text: 'ARUA_TECHNOS',
    opacity: 50,
    position: 'bottom-right',
    font: fontOptions[0].family,
    fontWeight: fontOptions[0].weights[0],
    fontStyle: fontOptions[0].styles[0],
    textSize: 5,
    textColor: '#ffffff',
    strokeColor: '#000000'
  });

  const [sourceImage, setSourceImage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setSourceImage(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSettingsChange = (newSettings: Partial<WatermarkSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      
      // If font family changes, reset weight and style to first available options
      if (newSettings.font) {
        const newFont = fontOptions.find(f => f.family === newSettings.font);
        if (newFont) {
          updated.fontWeight = newFont.weights[0];
          updated.fontStyle = newFont.styles[0];
        }
      }
      
      return updated;
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-center mb-8">
          <Droplets className="w-8 h-8 text-blue-600 mr-2" />
          <h1 className="text-4xl font-bold text-gray-900">ARUA_TECHNOS</h1>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <WatermarkForm
            settings={settings}
            onSettingsChange={handleSettingsChange}
            onImageUpload={handleImageUpload}
          />
          <WatermarkPreview
            settings={settings}
            sourceImage={sourceImage}
          />
        </div>
      </div>
    </div>
  );
}

export default App;