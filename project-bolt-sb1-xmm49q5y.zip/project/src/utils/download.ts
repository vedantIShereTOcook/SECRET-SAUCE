export function downloadImage(canvas: HTMLCanvasElement) {
  // Convert canvas to blob
  canvas.toBlob((blob) => {
    if (!blob) return;

    // Create download link
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `watermarked-image-${Date.now()}.png`;

    // Trigger download
    document.body.appendChild(link);
    link.click();

    // Cleanup
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, 'image/png');
}