export const fontOptions: FontOption[] = [
  {
    name: 'Playfair Display',
    family: '"Playfair Display"',
    weights: ['400', '500', '600', '700', '800', '900'],
    styles: ['normal', 'italic']
  },
  {
    name: 'Montserrat',
    family: 'Montserrat',
    weights: ['100', '200', '300', '400', '500', '600', '700', '800', '900'],
    styles: ['normal', 'italic']
  },
  {
    name: 'Roboto Slab',
    family: '"Roboto Slab"',
    weights: ['100', '200', '300', '400', '500', '600', '700', '800', '900'],
    styles: ['normal']
  },
  {
    name: 'Dancing Script',
    family: '"Dancing Script"',
    weights: ['400', '500', '600', '700'],
    styles: ['normal']
  },
  {
    name: 'Abril Fatface',
    family: '"Abril Fatface"',
    weights: ['400'],
    styles: ['normal']
  }
];