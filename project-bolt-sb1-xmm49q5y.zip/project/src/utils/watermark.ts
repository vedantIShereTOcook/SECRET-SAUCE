import { WatermarkSettings } from '../types';

export function drawWatermark(
  canvas: HTMLCanvasElement,
  image: HTMLImageElement,
  settings: WatermarkSettings
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Set canvas size to match image
  canvas.width = image.width;
  canvas.height = image.height;

  // Draw original image
  ctx.drawImage(image, 0, 0);

  // Apply watermark
  ctx.save();
  ctx.globalAlpha = settings.opacity / 100;

  if (settings.type === 'text' && settings.text) {
    // Configure text style
    const fontSize = Math.floor(image.width * (settings.textSize / 100));
    ctx.font = `${settings.fontStyle} ${settings.fontWeight} ${fontSize}px ${settings.font}`;
    ctx.fillStyle = settings.textColor;
    ctx.strokeStyle = settings.strokeColor;
    ctx.lineWidth = 2;

    const text = settings.text;
    const metrics = ctx.measureText(text);
    const textWidth = metrics.width;
    const textHeight = fontSize;

    // Calculate position
    const position = calculatePosition(
      settings.position,
      canvas.width,
      canvas.height,
      textWidth,
      textHeight
    );

    // Draw text with stroke for better visibility
    ctx.strokeText(text, position.x, position.y);
    ctx.fillText(text, position.x, position.y);
  }

  ctx.restore();
}

function calculatePosition(
  position: string,
  canvasWidth: number,
  canvasHeight: number,
  elementWidth: number,
  elementHeight: number
) {
  const padding = 20;
  const positions = {
    'top-left': { x: padding, y: padding + elementHeight },
    'top-center': { x: (canvasWidth - elementWidth) / 2, y: padding + elementHeight },
    'top-right': { x: canvasWidth - elementWidth - padding, y: padding + elementHeight },
    'middle-left': { x: padding, y: canvasHeight / 2 },
    'middle-center': { x: (canvasWidth - elementWidth) / 2, y: canvasHeight / 2 },
    'middle-right': { x: canvasWidth - elementWidth - padding, y: canvasHeight / 2 },
    'bottom-left': { x: padding, y: canvasHeight - padding },
    'bottom-center': { x: (canvasWidth - elementWidth) / 2, y: canvasHeight - padding },
    'bottom-right': { x: canvasWidth - elementWidth - padding, y: canvasHeight - padding }
  };

  return positions[position as keyof typeof positions];
}